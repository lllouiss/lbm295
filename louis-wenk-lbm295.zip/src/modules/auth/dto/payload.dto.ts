// src/auth/dto/payload.dto.ts
export class PayloadDto {
  sub!: number;
  username!: string;
}
